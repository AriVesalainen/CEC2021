sudo /etc/init.d/redis-server stop
#
#
#
sudo docker stop redisdb
sudo docker rm redisdb
#
#
#
sudo docker build -t my-redis .
#
#
#
sudo docker run -d -v /var/cec:/var/lib/redis -p 6379:6379 --name redisdb --net cec my-redis 
