#
date
./cec_benchmark.py 127.0.0.1:/test5  > stage1_5_5.txt
date
./cec_benchmark.py 127.0.0.1:/test3  > stage1_5_3.txt
date
./cec_benchmark.py 127.0.0.1:/test1  > stage1_5_1.txt
date

