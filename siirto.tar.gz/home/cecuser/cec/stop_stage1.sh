sudo /etc/init.d/redis-server stop
#
#
#
sudo docker stop redisdb
sudo docker rm redisdb
#
#
sudo docker stop  worker1
sudo docker stop  worker2
sudo docker stop  worker3
sudo docker stop  worker4
sudo docker stop  worker5
#
#
#
sudo docker rm  worker1
sudo docker rm  worker2
sudo docker rm  worker3
sudo docker rm  worker4
sudo docker rm  worker5
#
#
sudo docker stop  web-server
sudo docker rm    web-server
#
#
sudo docker ps -a
