#
#
sudo docker build -t worker .
#
#
#
sudo docker stop  worker1
sudo docker stop  worker2
sudo docker stop  worker3
sudo docker stop  worker4
sudo docker stop  worker5
#
#
#
sudo docker rm  worker1
sudo docker rm  worker2
sudo docker rm  worker3
sudo docker rm  worker4
sudo docker rm  worker5
#
#
sudo docker run --name worker1 -p 5010:5000 --net cec -d --cpus=".05"  worker
sudo docker run --name worker2 -p 5020:5000 --net cec -d --cpus=".05"  worker
sudo docker run --name worker3 -p 5030:5000 --net cec -d --cpus=".05"  worker
sudo docker run --name worker4 -p 5040:5000 --net cec -d --cpus=".05"  worker
sudo docker run --name worker5 -p 5050:5000 --net cec -d --cpus=".05"  worker

sudo docker ps -a
