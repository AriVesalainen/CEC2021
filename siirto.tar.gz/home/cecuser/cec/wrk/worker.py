
from flask import Flask
from redis import Redis

import os
import random
import string
import math

def getRndStr(length):
    letters = string.ascii_lowercase
    result = ''.join(random.choice(letters) for i in range(length))
    return result


def calcFactorial(n):
   try:
        f = math.factorial(n)
        r = float(f)
        return "Factorial of {} = {}".format(n,r)
   except Exception as e:
        return "Factorial of {} = infinite".format(n)


app = Flask(__name__)
bind_port = os.environ['BIND_PORT']
REDIS_HOST = os.environ['REDIS_HOST']
REDIS_PORT = os.environ['REDIS_PORT']

redis = Redis(host=REDIS_HOST, port=REDIS_PORT)

@app.route('/')
def hello():
#    redis.incr('hits')

    st = getRndStr(5)
    r = int(redis.get(st))
#    return 'Redis ({} {}) hit counter: {}'.format(st, r, redis.get('hits'))
    return  calcFactorial(r)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=bind_port, debug=True)
