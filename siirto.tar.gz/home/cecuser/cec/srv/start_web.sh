#
#
sudo docker build -t web-server .
#
#
#
sudo docker stop  web-server
sudo docker rm    web-server
#
#
sudo docker run --name web-server -p 80:5000 --net cec --env WORKERS=5 -d   web-server

sudo docker ps -a
