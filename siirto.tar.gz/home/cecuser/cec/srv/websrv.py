import random
import os

from flask import Flask, render_template, redirect
app = Flask(__name__)



@app.route('/')
def home():
    return "Hello world!"


@app.route('/test1')
def test1():
    workers_list = ["http://0.0.0.0:5010" ]

    rr = random.randint(0,len(workers_list)-1)
#    maxWrks = int(os.environ['WORKERS'])
#    rr = random.randint(0,maxWrks-1)

    return redirect (workers_list[rr])

@app.route('/test3')
def test3():
    workers_list = ["http://0.0.0.0:5010", "http://0.0.0.0:5020", "http://0.0.0.0:5030" ]

    rr = random.randint(0,len(workers_list)-1)
#    maxWrks = int(os.environ['WORKERS'])
#    rr = random.randint(0,maxWrks-1)

    return redirect (workers_list[rr])

@app.route('/test5')
def test5():

    workers_list = ["http://0.0.0.0:5010", "http://0.0.0.0:5020", "http://0.0.0.0:5030",
                    "http://0.0.0.0:5040", "http://0.0.0.0:5050" ]

    rr = random.randint(0,len(workers_list)-1)
#    maxWrks = int(os.environ['WORKERS'])
#    rr = random.randint(0,maxWrks-1)

    return redirect (workers_list[rr])

if __name__ == '__main__':

    app.run(debug=True, host='0.0.0.0')

