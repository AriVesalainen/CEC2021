#
# Execute stage1 steps A to D
#
#
# Execute Step A - getting-started

echo "Execute Step A"
echo " "
cd  /home/cecuser/Project/stage1/getting-started
#
#  Dockerfile exists
#
head -n 20 Dockerfile
#
# Build docker image
#
echo "Build docker image getting-started"
sudo docker build -t getting-started .
#
#  run docker container getting-started 
#
echo "Start docker container getting-started"
#
sudo docker run -dp 3000:3000 getting-started
echo "Getting-started container is running

sudo docker ps getting-started

echo "Press return to continue"
#
read -p "Press return to continue"
