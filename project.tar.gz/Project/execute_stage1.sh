#!/bin/bash
# Execute stage1 steps A to D
#
#
# Execute Step A - getting-started

echo "Execute Step A"
echo " "
cd  /home/cecuser/Project/stage1/getting-started
#
#  Dockerfile exists
#
head -n 20 Dockerfile
#
# Build docker image
#
#
read -p "Press return to continue"
echo "Build docker image getting-started"
sudo docker build -t getting-started .
#
#  run docker container getting-started 
#
#
read -p "Press return to continue"
echo "Start docker container getting-started"
#
sudo docker run -dp 3000:3000 getting-started
echo "Getting-started container is running"

sudo docker ps

#
read -p "Press return to continue"
#
#  First do some cleaning and stop and remove all containers  for Stage1
#
#
cd /home/cecuser/Project/stage1
bash ./stop_stage1.sh
#
#
# Execute Step B - Redis using snaphot
#
echo "Execute Step B"
#
sudo docker network create cec
#
cd /home/cecuser/Project/stage1/redis
bash ./start_redis.sh
#
#
#
cd ..
echo "Redis server is running"

sudo docker ps 
#
#
read -p "Press return to continue"

#
# Execute Step C - web server to calculate factorial for items stored in Redis db
#
cd /home/cecuser/Project/stage1/wrk
bash ./start_workers.sh
cd ..
#
read -p "Press return to continue"
#
# Execute Step D - start web balancer
#
cd /home/cecuser/Project/stage1/srv
bash ./start_web.sh
cd ..
#
#
#
sudo docker ps 
#
cd /home/cecuser/Project
#
echo "You can test the system by running commands:"
echo " "
echo "For one worker:"
echo "  ./cec_benchmark.py 127.0.0.1:/test1" 
echo " "
echo "For 3 workers:"
echo "  ./cec_benchmark.py 127.0.0.1:/test3"
echo " "
echo "For 5 workers:"
echo "  ./cec_benchmark.py 127.0.0.1:/test5"
#
#
./cec_benchmark.py 127.0.0.1:/test5
