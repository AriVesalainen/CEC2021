#
# Make sure redis server started during the startuo is stopped and we can  run  redis in
# container (uses standard port 6379)
#
sudo /etc/init.d/redis-server stop
#
# Stop and remove all redisdb containers to ensure we have a "clean" system
#
sudo docker stop redisdb
sudo docker rm redisdb
#
# Build new redis docker image "my-redis", Dockerfile includes the key parameters needed for run time
#
sudo docker build -t my-redis .
#
# Start redis server in container
#   uses the database stored in /var/cec
#   listens to port 6379
#   name of container is redisdb
#   uses host network cec
#   image name is my-redis
#
sudo docker run -d -v /var/cec:/var/lib/redis -p 6379:6379 --name redisdb --net cec my-redis 
#
#
