#
# Import required libraries
#
from flask import Flask
from redis import Redis

import os
import random
import string
import math
#
# Generate a random string of length characters, all in lower case
# this is used as a key to redis database
#
def getRndStr(length):
    letters = string.ascii_lowercase
    result = ''.join(random.choice(letters) for i in range(length))
    return result

#
# Calculate factorial of n using mth.factorial
# Result is in integer format and  this converted to float format
# if float conversion gives an exception we have an overflow and result is infinite
# Function returns the message to be replied to original requestor
#

def calcFactorial(n):
   try:
        f = math.factorial(n)
        r = float(f)
        return "Factorial of {} = {}".format(n,r)
   except Exception as e:
        return "Factorial of {} = infinite".format(n)


app = Flask(__name__)


bind_port = os.environ['BIND_PORT']
#
#  Connect to Redis server which is running in another container

REDIS_HOST = os.environ['REDIS_HOST']
REDIS_PORT = os.environ['REDIS_PORT']

redis = Redis(host=REDIS_HOST, port=REDIS_PORT)

#
# All requests to '/' are handled 
#
@app.route('/')
def hello():

#
#   Create random key (5-letter string) and get the corrspnding value from redis db
#   and reurn the message to requestor
#
    st = getRndStr(5)
    r = int(redis.get(st))
    return  calcFactorial(r)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=bind_port, debug=True)
