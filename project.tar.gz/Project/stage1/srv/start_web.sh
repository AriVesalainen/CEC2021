#
#  Build web-server image based on Dockerfile in the same directory
#
sudo docker build -t web-server .
#
# Some cleaning in order to ensure we don't have  old container running 
#
sudo docker stop  web-server
sudo docker rm    web-server
#
# Start web-server container
#    name of container is web-server
#    host port is 80 and internal port 5000
#    use host network cec
#    environmental vriable WORKERS is 5
#    name of the image is web-server, i.e. which was just build above
#
sudo docker run --name web-server -p 80:5000 --net cec --env WORKERS=5 -d   web-server
#
#
#
#sudo docker ps -a
