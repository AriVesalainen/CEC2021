#
# Import required libraries
#
import random
import os

from flask import Flask, render_template, redirect
app = Flask(__name__)

#
# For testing purpose / to check if server is alive
#

@app.route('/')
def home():
    return "Hello world!"

#
#  When web server is accessed using "/test1" only one worker is utilize
#

@app.route('/test1')
def test1():

    worker1 = os.environ['WORKER1'] 

#
#   send a redirect to original requestor
#
    return redirect (worker1)

#
#  When web server is accessed using "/test3" three workers are utilized
#
@app.route('/test3')
def test3():
#
# urls for workers are provided through env variables
#
    worker1 = os.environ['WORKER1'] 
    worker2 = os.environ['WORKER2'] 
    worker3 = os.environ['WORKER3']
 
    workers_list = [worker1, worker2, worker3 ]
#
# Pick the url for one of the workers by random
# Decided to use random approach rather and pure round robin. Round robin could be implemented
# by using redis database to record "hits" and just calculating the which worker would be the next
#
    rr = random.randint(0,len(workers_list)-1)

#
#   send a redirect to original requestor
#
    return redirect (workers_list[rr])

#
#  When web server is accessed using "/test5" five workers are utilized
#
@app.route('/test5')
def test5():
#
# urls for workers are provided thorugh env variables
#
    worker1 = os.environ['WORKER1'] 
    worker2 = os.environ['WORKER2'] 
    worker3 = os.environ['WORKER3'] 
    worker4 = os.environ['WORKER4'] 
    worker5 = os.environ['WORKER5'] 

#
    workers_list = [worker1, worker2, worker3, worker4, worker5 ]
#
# Pick the url for one of the workers by random
# Decided to use random approach rather and pure round robin. Round robin could be implemented
# by using redis database to record "hits" and just calculating the which worker would be the next
#
    rr = random.randint(0,len(workers_list)-1)

#
#   send a redirect to original requestor
#
    return redirect (workers_list[rr])

if __name__ == '__main__':

    app.run(debug=True, host='0.0.0.0')

