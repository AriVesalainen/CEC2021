#!/bin/bash
#
#
sudo docker service rm stage2_redisdb
sudo docker service rm stage2_worker
#
#
cd /home/cecuser/Project/stage2
#
# 
#
echo "Build docker images"
sudo docker-compose build
#
#
#
echo "Build Services"

sudo docker stack deploy -c swarm.yml stage2
sudo docker service ls

echo "Run with one server"
date
sudo docker ps
cd /home/cecuser/Project
sudo docker service scale stage2_worker=1
./cec_benchmark.py 0.0.0.0:5000  >test.txt
tail -n 21 test.txt >performance/stage2_1w.csv
rm test.txt

echo "Run with three servers"
date
sudo docker ps
sudo docker service scale stage2_worker=3
./cec_benchmark.py 0.0.0.0:5000 >test.txt
tail -n 21 test.txt >performance/stage2_3w.csv
rm test.txt

echo "Run with five servers"
date
sudo docker ps
sudo docker service scale stage2_worker=5
./cec_benchmark.py 0.0.0.0:5000 >test.txt 
tail -n 21 test.txt >performance/stage2_5w.csv
rm test.txt
date
