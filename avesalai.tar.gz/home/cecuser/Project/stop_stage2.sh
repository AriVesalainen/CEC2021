#!/bin/bash
#
# Run some cleaning first
#
sudo docker service rm stage2_redisdb
sudo docker service rm stage2_worker
sudo docker swarm leave --force
