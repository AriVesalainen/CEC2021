#
# Build  docker image worker, all workers will use the same image
#
sudo docker build -t worker .
#
# Stop and remove worker containers if  running earlier
# if doesn't exist this will show an error message, but this is ok
#
sudo docker stop  worker1
sudo docker stop  worker2
sudo docker stop  worker3
sudo docker stop  worker4
sudo docker stop  worker5
#
#
#
sudo docker rm  worker1
sudo docker rm  worker2
sudo docker rm  worker3
sudo docker rm  worker4
sudo docker rm  worker5
#
# Run worker web server, this starts all 5 workers even if only 1, 3 or 5 are used for tests
#    name of container is worker<n>
#    host port is 50X0 which is mapped to container internal posrt 5000
#    uses host net cec
#    cpu in containmer is limited to 5%
#    image name is worker as built above
#

sudo docker run --name worker1 -p 5010:5000 --net cec -d --cpus=".25"  worker
sudo docker run --name worker2 -p 5020:5000 --net cec -d --cpus=".25"  worker
sudo docker run --name worker3 -p 5030:5000 --net cec -d --cpus=".25"  worker
sudo docker run --name worker4 -p 5040:5000 --net cec -d --cpus=".25"  worker
sudo docker run --name worker5 -p 5050:5000 --net cec -d --cpus=".25"  worker
#
#sudo docker ps -a
