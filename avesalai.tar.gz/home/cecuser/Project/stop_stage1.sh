#!/bin/bash
#  Stop Stage1 containers
#

cd /home/cecuser/Project/stage1
./stop_stage1.sh
cd /home/cecuser/Project
