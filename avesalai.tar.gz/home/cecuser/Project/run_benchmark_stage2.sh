#!/bin/bash
echo ""
echo "Run cenchmarking for stage2"
echo ""
#
#  Ensure we have one web server running
#
echo "Run with one server"
date
sudo docker ps
cd /home/cecuser/Project
sudo docker service scale stage2_worker=1
#
# run benchmark and store results in csv format into benchmark folder
#
./cec_benchmark.py 0.0.0.0:5000  >test.txt
tail -n 21 test.txt >benchmark/stage2_1w.csv
rm test.txt
#
#  Ensure we have three web servers running
#
echo "Run with three servers"
date
sudo docker ps
sudo docker service scale stage2_worker=3
#
# run benchmark and store results in csv format into benchmark folder
#
./cec_benchmark.py 0.0.0.0:5000 >test.txt
tail -n 21 test.txt >benchmark/stage2_3w.csv
rm test.txt
#
#  Ensure we have five web servers running
#

echo "Run with five servers"
date
sudo docker ps
sudo docker service scale stage2_worker=5
#
# run benchmark and store results in csv format into benchmark folder
#
./cec_benchmark.py 0.0.0.0:5000 >test.txt
tail -n 21 test.txt >benchmark/stage2_5w.csv
rm test.txt
date
