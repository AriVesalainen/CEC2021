
sudo docker service create --name websrv \
--publish published=8080,target=5000 \
--replicas 2  stage2_worker
