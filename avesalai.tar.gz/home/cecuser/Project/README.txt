CEC 2021 Project
================
Folder structure, more details below

stage1
    getting-started
    redis
    wrk
    srv

stage2
    redis
    wrk
benchmark

Explanations

README.txt - this file

cec_benchmark.py - benchmarking script provided

execute_stage1.sh - run stage 1 tasks, benchmark to be done separately

run_benchmark_stage1.sh - run benchmark for stage1 after all definitions are done and containers 
are up and running

stop_stage1.sh - shutdown stage1 containers

execute_stage2.sh - run stage 2 tasks

run_benchmark_stage2.sh - run benchmark for stage2 after all definitions are done and containers 
are up and runningservice is deployed

stop_stage2.sh - shutdown stage2 services



stage1
======
all files for stage1 tasks
docker-compose.yml - docker definitions for docker-compose, however, not used in final version

getting-started
===============

folder for task A "Start the bulletinboard app in a container". 
Necessary steps to run this included in execute_stage1.sh script

redis
=====

folder for task B "Run redis app in a container using given snapshot". 

Dockerfile - defintions to run redis in container
redis.conf - special redis configuration to use snapshot database provided
start_redis.sh - simple script to run redis in docker container

wrk
===

folder for task C "HTTP server which pulls data from redis server and calculates the factorial". 

Dockerfile - definitions to run web server worker in container
requirements.txt - required python libraries
start_workers.sh - simple script to start and run 5 workes
worker.py - python code for worker web server

srv
===

folder for task D "Load balancing access node". It uses HTTP redirect to dsirtibute client 
requests to workers. Load balancing is done on random, i.e. it selects the worker node randomly
based on the number of workers available. This should guarantee roughly even distribution between
workers. 

For simplicity the same configuration handles all use cases, i.e.
if balancer web node is accessed using "/" it returns "Hello World", this is used for testing
if balancer web node is accessed using "/test1" it redirects to one and only worker
if balancer web node is accessed using "/test3" it redirects the request randomly to one of the
three workers
if balancer web node is accessed using "/test5" it redirects the request randomly to one of the
five workers

Dockerfile - definitions to run web server balancer in container
requirements.txt - required python libraries
start_web.sh - simple script to start and run web balancer
websrv.py - python code for balancer web server

stage2
======

all files for stage2 tasks

docker-compose.yml: docker defintion file for building "redis" and "web server worker" services images 

swarm.yml: docker definitions files for creating docker services for "redis" and 
"web server worker" 

redis
=====

Same as for Stage1

wrk
===

Same as for Stage1


benchmark
=========
all files for analysis

analysis.pdf - Explanations of benchmarking results and explanations

plots.pdf - graphs of benchmarking results

stage1_1w.csv:
results of cec_benchmark.py for own balancer running with one worker

stage1_3w.csv:
results of cec_benchmark.py for own balancer running with three workers

stage1_5w.csv:
results of cec_benchmark.py for own balancer running with five workers

stage2_1w.csv:
results of cec_benchmark.py for swarn balancer running with one worker

stage2_3w.csv:
results of cec_benchmark.py for swarn balancer running with three workers

stage2_5w.csv:
results of cec_benchmark.py for swarn balancer running with five workers

-------


