#!/bin/bash
#
# Run some cleaning first
#
sudo docker service rm stage2_redisdb
sudo docker service rm stage2_worker
sudo docker swarm leave --force
#
# Create swarm we need for the swarm balancer
#
sudo docker swarm init
#
#
cd /home/cecuser/Project/stage2
#
# Build docker images for web server and redis
# We are using exactly the same code for stage2 as in stage1
#
#
echo ""
echo "Execute Step A - docker-compose.yml includes the service definitions"
echo ""
more docker-compose.yml
#
#
echo ""
echo "Build docker images using docker-compose.yml"
echo ""
sudo docker-compose build
#
# Build  docker services and deploy based on images
#
echo ""
echo "Execute Step B - swarm.yml includes definitions to deploy services "

sudo docker stack deploy -c swarm.yml stage2
sudo docker service ls
echo ""
echo "Run cenchmarking for stage2"
echo ""
#
echo "Steps Stage 2 A-B executed and service is up and running"

sudo docker ps 
#
cd /home/cecuser/Project
#
echo " "
echo " "
echo " "
echo "You can run the benchmark tests by executing the script: ./run_benchmark_stage2.sh"
#
#
