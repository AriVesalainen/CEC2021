#!/bin/bash
#  Run tests with 5,3 and 1 workers and store results in performance folder in csv format
#
#
echo "Running test5"
date
./cec_benchmark.py 127.0.0.1:/test5 > test.txt
tail -n 21 test.txt >benchmark/stage1_5w.csv
rm test.txt
echo "Running test3"
date
./cec_benchmark.py 127.0.0.1:/test3 > test.txt
tail -n 21 test.txt >benchmark/stage1_3w.csv
rm test.txt
echo "Running test1"
date
./cec_benchmark.py 127.0.0.1:/test1 > test.txt
tail -n 21 test.txt >benchmark/stage1_1w.csv
rm test.txt
date
