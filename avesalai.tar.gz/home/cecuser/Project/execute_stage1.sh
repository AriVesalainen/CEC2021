#!/bin/bash
# Execute stage1 steps A to D
#
#
# Execute Step A - getting-started

echo " "
echo "Execute Step A"
echo " "
cd  /home/cecuser/Project/stage1/getting-started
#
#  Dockerfile exists
#
head -n 20 Dockerfile
#
# Build docker image
#
#
read -p "Press return to continue"
echo " "
echo "Build docker image getting-started"
echo " "
sudo docker build -t getting-started .
#
#  run docker container getting-started 
#
#
read -p "Press return to continue"
echo " "
echo "Start docker container getting-started"
echo " "
#
sudo docker run -dp 3000:3000 getting-started
echo "Getting-started container is running"

sudo docker ps

#
read -p "Press return to continue"
#
#  First do some cleaning and stop and remove all containers  for Stage1
#
#
cd /home/cecuser/Project/stage1
bash ./stop_stage1.sh
#
#
# Execute Step B - Redis using snaphot
#
echo " "
echo "Execute Step B - start Redis server"
echo " "
#
sudo docker network create cec
#
cd /home/cecuser/Project/stage1/redis
bash ./start_redis.sh
#
#
#
cd ..
echo " "
echo "Redis server is running"
echo " "

sudo docker ps  | grep redis
#
#
read -p "Press return to continue"

#
# Execute Step C - web server to calculate factorial for items stored in Redis db
#
echo " "
echo "Execute Step C - start worker web server"
echo " "
cd /home/cecuser/Project/stage1/wrk
bash ./start_workers.sh
cd ..
sudo docker ps  | grep  wrk
#
read -p "Press return to continue"
#
# Execute Step D - start web balancer
#
echo " "
echo "Execute Step D - start web balancer"
echo " "
cd /home/cecuser/Project/stage1/srv
bash ./start_web.sh
sudo docker ps  | grep  websrv

cd ..
#
#
#
echo "Steps A-D executed and 4 containers running"

sudo docker ps 
#
cd /home/cecuser/Project
#
echo " "
echo " "
echo " "
echo "You can run the benchmark tests by executing the script: ./run_benchmark_stage1.sh"
#
#
